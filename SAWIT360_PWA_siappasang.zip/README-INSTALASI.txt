SAWIT360 — PWA
================

PUBLISH KE GITHUB PAGES
1. Login/buat akun GitHub.
2. Create new repository: sawit360
3. Upload semua isi folder ini.
4. Settings > Pages.
5. Source: Deploy from a branch.
6. Branch: main, folder: /(root), Save.
7. Setelah aktif, buka:
   https://USERNAME.github.io/sawit360/
8. Di Chrome Android: menu ⋮ > Install app / Add to Home screen > Install.

PENTING
- Ini masih prototype.
- Data belum tersimpan ke database online dan belum ada login.
- Untuk data petani/utang nyata, tahap berikutnya harus memakai database + autentikasi.
